# Starter CRM

A minimal CRM you run from this folder: one SQLite file, the 11-stage pipeline from Stage 5,
and events that move deals on their own. Claude Code wires it to your tools using the prompts
in `prompts/`. No third-party automation platform is involved.

## What's in the folder

| File | What it is |
|---|---|
| `pipeline.json` | The pipeline: 11 stages + the No Show exit, the entry event for each, its owner and its guard; the front stages per mechanism (webinar, reverse squeeze page, challenge); the four extra pipelines. |
| `fields.json` | The tags and fields, with exactly the names the guides use. The four canonical tags are never renamed. |
| `schema.sql` | Tables: contacts, tags, deals, events (append-only), scheduled_messages. |
| `crm.py` | The core, standard library only: `init`, `add`, `event`, `board`, `show`. |
| `prompts/` | Claude Code prompts that build the connections, one per file. |

## Status: what is built and what you build

| Piece | Status |
|---|---|
| Pipeline, fields and tags (`pipeline.json`, `fields.json`) | **BUILT** |
| Database schema (`schema.sql`) | **BUILT** |
| Core: contacts, events, event → stage moves, tags, board (`crm.py`) | **BUILT** |
| Intake from your form and booking tool (`prompts/01-intake.md`) | PLANNED: you build it with the prompt |
| Payments → Payment Completed (`prompts/02-payments.md`) | PLANNED |
| Reminders and follow-ups for every stage (`prompts/03-follow-up-runner.md`) | PLANNED |
| The four extra pipelines (`prompts/04-extra-pipelines.md`) | PLANNED |
| A local pipeline board in the browser (`prompts/05-board.md`) | PLANNED |
| Running it every 5 minutes (`prompts/06-schedule-it.md`) | PLANNED |

## Start

```bash
python3 crm.py init
python3 crm.py add you@example.com --name You --source test --mechanism webinar
python3 crm.py event you@example.com form.submitted
python3 crm.py event you@example.com booking.created
python3 crm.py event you@example.com booking.no_show
python3 crm.py board
python3 crm.py show you@example.com
```

The No Show column now holds one deal, and the contact has the `call-no-show` tag, and you
never moved anything by hand. That is the whole idea: tools report events, and events move deals.

## The rules it keeps

- A stage is only ever entered by its `entry_event` (see `pipeline.json`). Nothing is dragged by hand.
- Front-of-funnel events (registered, attended, replay watched) add their tag but never drag a
  deal backwards out of the main chain.
- `payment.succeeded` adds `purchased`; `booking.no_show` adds `call-no-show`.
- Keys and passwords live in `.env`, which is git-ignored. Never paste them into a prompt.
- Runs on your own machine. Webhooks can't reach it, so the intake and payment prompts poll
  each tool's API instead.
