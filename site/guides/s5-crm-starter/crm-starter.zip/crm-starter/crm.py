#!/usr/bin/env python3
"""Starter CRM: one SQLite file, the 11-stage pipeline, and event → stage moves.

Standard library only. What it does today (BUILT):
  python3 crm.py init                        create crm.db from schema.sql
  python3 crm.py add EMAIL [--name N] [--source S] [--mechanism webinar|rsp|challenge]
  python3 crm.py event EMAIL TYPE [--source S]   record an event; moves the deal if TYPE is a stage's entry_event
  python3 crm.py board                       print the pipeline with a count per stage
  python3 crm.py show EMAIL                  contact, tags, stage and event history

Everything that talks to other tools (booking, payments, email/SMS/WhatsApp
sending, the reminder runner, a web dashboard) is PLANNED: you build it with
Claude Code using the prompts in prompts/, and it calls `record_event()`.
"""
import argparse, json, sqlite3, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB = HERE / "crm.db"
PIPELINE = json.loads((HERE / "pipeline.json").read_text())
STAGES = PIPELINE["stages"]
BY_EVENT = {s["entry_event"]: s for s in STAGES}
for mech, front in PIPELINE["mechanism_front_stages"].items():
    for s in front:
        BY_EVENT.setdefault(s["entry_event"], {**s, "mechanism": mech})
TAG_ONLY_EVENTS = {"vsl_progress_25": "depth-25", "vsl_progress_50": "depth-50", "event.day1_no_show": "no-show-day-1", "event.day2_no_show": "no-show-day-2", "event.day3_no_show": "no-show-day-3"}
PRIORITY_BY_STAGE = {"eval_call_scheduled": "P2", "follow_up": "P1", "proposal_sent": "P1"}


def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init() -> None:
    with db() as con:
        con.executescript((HERE / "schema.sql").read_text())
    print(f"created {DB.name} with {len(STAGES)} pipeline columns")


def contact_id(con, email: str) -> int:
    row = con.execute("SELECT id FROM contacts WHERE email = ?", (email.lower(),)).fetchone()
    if not row:
        sys.exit(f"no contact {email}. Add it first: python3 crm.py add {email}")
    return row["id"]


def add(email, name=None, source=None, mechanism=None) -> int:
    with db() as con:
        con.execute(
            "INSERT INTO contacts (email, first_name, source, mechanism) VALUES (?,?,?,?) "
            "ON CONFLICT(email) DO UPDATE SET first_name = COALESCE(excluded.first_name, first_name), "
            "source = COALESCE(source, excluded.source), mechanism = COALESCE(excluded.mechanism, mechanism)",
            (email.lower(), name, source, mechanism))
        return contact_id(con, email)


def record_event(email: str, type_: str, source: str | None = None, payload: dict | None = None) -> str | None:
    """Store the event; if it is a stage's entry event, move (or open) the deal. Returns the new stage key."""
    with db() as con:
        cid = contact_id(con, email)
        con.execute("INSERT INTO events (contact_id, type, source, payload) VALUES (?,?,?,?)",
                    (cid, type_, source, json.dumps(payload or {})))
        if type_ in TAG_ONLY_EVENTS:
            con.execute("INSERT OR IGNORE INTO tags (contact_id, tag) VALUES (?, ?)", (cid, TAG_ONLY_EVENTS[type_]))
            return None
        stage = BY_EVENT.get(type_)
        if not stage:
            return None
        deal = con.execute("SELECT id FROM deals WHERE contact_id = ? AND pipeline = 'sales'", (cid,)).fetchone()
        main_keys = {s["key"] for s in STAGES}
        if deal and "mechanism" in stage:
            cur = con.execute("SELECT stage FROM deals WHERE id = ?", (deal["id"],)).fetchone()["stage"]
            if cur in main_keys:  # front-of-funnel events never drag a deal back out of the main chain
                if stage.get("adds_tag"):
                    con.execute("INSERT OR IGNORE INTO tags (contact_id, tag) VALUES (?, ?)", (cid, stage["adds_tag"]))
                return None
        if deal:
            con.execute("UPDATE deals SET stage = ?, updated_at = datetime('now') WHERE id = ?", (stage["key"], deal["id"]))
        else:
            con.execute("INSERT INTO deals (contact_id, stage) VALUES (?, ?)", (cid, stage["key"]))
        if stage.get("adds_tag"):
            con.execute("INSERT OR IGNORE INTO tags (contact_id, tag) VALUES (?, ?)", (cid, stage["adds_tag"]))
        if stage["key"] in PRIORITY_BY_STAGE:
            con.execute("UPDATE contacts SET priority = ? WHERE id = ?", (PRIORITY_BY_STAGE[stage["key"]], cid))
        return stage["key"]


def board() -> None:
    with db() as con:
        counts = dict(con.execute("SELECT stage, COUNT(*) FROM deals WHERE pipeline = 'sales' GROUP BY stage").fetchall())
    front = [s for f in PIPELINE["mechanism_front_stages"].values() for s in f if counts.get(s["key"])]
    for s in front:
        print(f"      {s['name']:<22} {counts[s['key']]:>4}")
    for s in STAGES:
        print(f"{s['n']:>4}  {s['name']:<22} {counts.get(s['key'], 0):>4}{'   (exit)' if s.get('exit') else ''}")


def show(email: str) -> None:
    with db() as con:
        cid = contact_id(con, email)
        c = dict(con.execute("SELECT * FROM contacts WHERE id = ?", (cid,)).fetchone())
        tags = [r[0] for r in con.execute("SELECT tag FROM tags WHERE contact_id = ?", (cid,))]
        deal = con.execute("SELECT stage FROM deals WHERE contact_id = ?", (cid,)).fetchone()
        events = con.execute("SELECT at, type, source FROM events WHERE contact_id = ? ORDER BY id", (cid,)).fetchall()
    print(json.dumps({k: v for k, v in c.items() if v is not None}, indent=1))
    print("tags:", ", ".join(tags) or "—")
    print("stage:", deal["stage"] if deal else "—")
    for e in events:
        print(f"  {e['at']}  {e['type']:<24} {e['source'] or ''}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init"); sub.add_parser("board")
    a = sub.add_parser("add"); a.add_argument("email"); a.add_argument("--name"); a.add_argument("--source")
    a.add_argument("--mechanism", choices=["webinar", "rsp", "challenge"])
    e = sub.add_parser("event"); e.add_argument("email"); e.add_argument("type"); e.add_argument("--source")
    s = sub.add_parser("show"); s.add_argument("email")
    args = p.parse_args()
    if args.cmd == "init": init()
    elif args.cmd == "add": print("contact", add(args.email, args.name, args.source, args.mechanism))
    elif args.cmd == "event":
        moved = record_event(args.email, args.type, args.source)
        print(f"recorded {args.type}" + (f" → stage {moved}" if moved else " (no stage change)"))
    elif args.cmd == "board": board()
    elif args.cmd == "show": show(args.email)


if __name__ == "__main__":
    main()
