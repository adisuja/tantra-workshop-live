-- Starter CRM schema (SQLite). Created by `python3 crm.py init`.
-- Stages, fields and tags come from pipeline.json and fields.json; this file
-- only holds the tables. Every stage change is an event row, so the board is
-- always derivable from what actually happened.

CREATE TABLE IF NOT EXISTS contacts (
  id               INTEGER PRIMARY KEY,
  email            TEXT UNIQUE NOT NULL,
  first_name       TEXT,
  phone            TEXT,
  source           TEXT,
  utm_source       TEXT, utm_medium TEXT, utm_campaign TEXT, utm_content TEXT,
  mechanism        TEXT CHECK (mechanism IN ('webinar','rsp','challenge') OR mechanism IS NULL),
  diagnostic_score REAL,
  score_band       TEXT,
  priority         TEXT DEFAULT 'P3' CHECK (priority IN ('P1','P2','P3')),
  owner            TEXT,
  next_action_date TEXT,
  consent_email    INTEGER DEFAULT 1,
  consent_sms      INTEGER DEFAULT 0,
  consent_whatsapp INTEGER DEFAULT 0,
  created_at       TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tags (
  contact_id INTEGER NOT NULL REFERENCES contacts(id),
  tag        TEXT NOT NULL,
  added_at   TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (contact_id, tag)
);

CREATE TABLE IF NOT EXISTS deals (
  id                  INTEGER PRIMARY KEY,
  contact_id          INTEGER NOT NULL REFERENCES contacts(id),
  pipeline            TEXT NOT NULL DEFAULT 'sales',
  stage               TEXT NOT NULL,
  deal_value          REAL,
  proposal_sent_at    TEXT,
  proposal_expires_at TEXT,
  lost_reason         TEXT,
  reengage_after      TEXT,
  updated_at          TEXT DEFAULT (datetime('now'))
);

-- Append-only: what happened, from which system. The stage is a consequence.
CREATE TABLE IF NOT EXISTS events (
  id          INTEGER PRIMARY KEY,
  contact_id  INTEGER NOT NULL REFERENCES contacts(id),
  type        TEXT NOT NULL,          -- e.g. booking.created, payment.succeeded
  source      TEXT,                   -- e.g. calendar, payments, event-platform
  payload     TEXT,                   -- raw JSON as received
  at          TEXT DEFAULT (datetime('now'))
);

-- Planned: filled by the follow-up runner you build with prompts/03.
CREATE TABLE IF NOT EXISTS scheduled_messages (
  id          INTEGER PRIMARY KEY,
  contact_id  INTEGER NOT NULL REFERENCES contacts(id),
  sequence    TEXT NOT NULL,          -- e.g. call-reminders, no-show-recovery
  step        INTEGER NOT NULL,
  channel     TEXT NOT NULL CHECK (channel IN ('email','sms','whatsapp','call-task')),
  due_at      TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','cancelled','failed')),
  cancelled_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_deals_stage ON deals(pipeline, stage);
CREATE INDEX IF NOT EXISTS idx_events_contact ON events(contact_id, at);
CREATE INDEX IF NOT EXISTS idx_msgs_due ON scheduled_messages(status, due_at);
