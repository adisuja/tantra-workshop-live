# Prompt 05 · A Local Pipeline Board

**Status: PLANNED.**

```
Read crm.py and schema.sql. Build board.py: a small local web page (standard library
http.server, or FastAPI if I say so) on http://localhost:8765 that shows each pipeline as
columns in pipeline.json order, a card per deal (name, source, priority, next_action_date,
days in stage), the No Show and Unqualified exits in their own colour, and a contact page
with the event history from `crm.py show`. Read-only: stages move only through events.
```
