# Prompt 03 · The Follow-Up Runner (Every Stage's Reminders and Follow-Ups)

**Status: PLANNED.** Needs your sequences: the `follow-ups/` folder the Stage 5 follow-ups
prompt generates, saved next to the `crm-starter` folder.

```
Read README.md, pipeline.json, fields.json, schema.sql, crm.py and every file in ../follow-ups/
(one sequence per stage: trigger, exit, steps with offsets, channel and copy). If that folder
is missing, stop and tell me. If the sequences are prose, first rewrite each one as a JSON
file there: sequence name, the stage it belongs to, the trigger event, the exit events, and
steps with an offset ("+15m", "+3d", or "T-24h" for before a booked call), a channel, a
subject and a body. Show me the files before you go on.

Build runner.py. Only crm.py writes contacts, deals and events; runner.py owns the
scheduled_messages table and may add columns to it (for example the id of the event that
scheduled a row), never remove any.
1. SCHEDULE: whenever a deal enters a stage (a new row in `events` whose type is a
   sequence's trigger), insert that sequence's steps into scheduled_messages with due_at =
   event time + offset. Offsets before a booked call (T-48h, T-24h, T-1h) count back from
   the booking time in the event payload ("start"); skip a step whose time has already
   passed. Remember the last event handled, so nothing is scheduled twice.
2. CANCEL: before sending anything, cancel every pending message for that contact whose
   sequence belongs to a stage the deal has left, and every pending message if the contact
   replied (event "message.replied"), booked, or hit the sequence's exit since it was
   scheduled (cancelled_reason says which).
3. SEND: every 5 minutes, send what is due inside a ±3 minute window. A message older than
   the window (the machine was asleep) is marked failed, never sent late.
   - email through <Resend / Gmail / my provider>
   - SMS through <Twilio / my provider>, only if consent_sms = 1, one segment
     (160 GSM-7 characters, or 70 if the text has an emoji or a non-GSM character)
   - WhatsApp through <my WhatsApp Business provider>, only if consent_whatsapp = 1, and only
     with approved templates for business-initiated messages
   - call-task: write it to a tasks list for the owner instead of sending anything
   A channel with no provider set in .env is held, not failed.
   Fill {placeholders} from the contact and deal. Never send a message with an unfilled
   placeholder: mark it failed and tell me.
4. Log every send as an event (message.sent / message.failed) with the sequence, step,
   channel and the provider's message id. My machine can't receive open webhooks, so ask
   the email provider for each recent message's status and record "email.opened".
5. Add a --dry-run flag that prints what would be sent in the next 24 hours and changes
   nothing in crm.db.
6. While I test: read SEND_ONLY_TO from .env and hold every email to any other address.

Keys go in .env, never in code. Show me --dry-run output for a test contact before you
switch real sending on. Update README.md's status table for this prompt.
```
