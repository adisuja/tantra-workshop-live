# Prompt 03 · The Follow-Up Runner (Every Stage's Reminders and Follow-Ups)

**Status: PLANNED.** Needs the `follow-ups/` folder the Stage 5 survey prompt generates.

```
Read README.md, pipeline.json, fields.json, schema.sql, crm.py and every file in ../follow-ups/
(one sequence per stage: trigger, exit, steps with offsets, channel and copy).

Build runner.py:
1. SCHEDULE: whenever a deal enters a stage (a new row in `events` whose type is a stage's
   entry_event), insert that stage's sequence steps into scheduled_messages with due_at =
   event time + offset. Offsets before a booked call (T-48h, T-24h, T-1h) count back from
   the booking time in the event payload.
2. CANCEL: before sending anything, cancel every pending message for that contact whose
   sequence belongs to an earlier stage, and every pending message if the contact replied,
   booked or changed stage since it was scheduled (cancelled_reason says which).
3. SEND: every 5 minutes, send what is due inside a ±3 minute window:
   - email through <Resend / Gmail / my provider>
   - SMS through <Twilio / my provider>, only if consent_sms = 1, one segment
     (160 GSM-7 characters, or 70 if the text has an emoji or a non-GSM character)
   - WhatsApp through <my WhatsApp Business provider>, only if consent_whatsapp = 1, and only
     with approved templates for business-initiated messages
   - call-task: write it to a tasks list for the owner instead of sending anything
   Fill {placeholders} from the contact and deal. Never send a message with an unfilled
   placeholder: mark it failed and tell me.
4. Log every send as an event (message.sent / message.failed).
5. Add a --dry-run flag that prints what would be sent in the next 24 hours.

Keys go in .env, never in code. Show me --dry-run output for a test contact before you
switch real sending on. Update README.md's status table for this prompt.
```
