# Prompt 04 · The Four Extra Pipelines

**Status: PLANNED.**

```
Read pipeline.json (extra_pipelines), crm.py and runner.py.

Extend crm.py (keep its existing commands working) so a contact can have one deal in the
main 'sales' pipeline AND one deal in each extra pipeline:
- no_show_recovery: opened by booking.no_show; closed as Rebooked by booking.created,
  or Ghosted (tag `ghosted`) 7 days after entry with no reply.
- nurture_back: opened by tag `nurture` or lost_reason = timing; moves to Warming when
  reengage_after arrives or they open/click in the last 30 days.
- referral: opened when I record event "checkin.positive"; referred leads get tag `referral`.
- re_engagement: a daily check opens it for contacts with no email opens in 90 days;
  a reply tags `reactivated` and moves them back to Form Filled in the main pipeline;
  10 unopened sends marks them Suppressed.
Add `python3 crm.py board --pipeline <name>` and a weekly review command that lists cards with
no next_action_date or no movement in 14 days.
```
