# Prompt 04 · The Four Extra Pipelines

**Status: PLANNED.** Run it after Prompt 03: two of the pipelines read the runner's events.

```
Read pipeline.json (extra_pipelines), crm.py and runner.py.

Extend crm.py (keep its existing commands working) so a contact can have one deal in the
main 'sales' pipeline AND one deal in each extra pipeline. `show` must print the main stage
and each extra pipeline's stage:
- no_show_recovery: opened by booking.no_show; moves to Rebook Offered when the runner
  sends the first no-show message; closed as Rebooked by booking.created, or Ghosted
  (tag `ghosted`) 7 days after the no-show with no reply (event "message.replied").
- nurture_back: opened by tag `nurture` or lost_reason = timing; moves to Warming when
  reengage_after arrives or they opened or clicked ("email.opened", "email.clicked") in
  the last 30 days. Add `python3 crm.py tag <email> <tag>` and
  `python3 crm.py lost <email> --reason <reason> [--reengage-after <date>]` so I can do both.
- referral: opened when I record event "checkin.positive"; referred leads get tag `referral`.
- re_engagement: a daily check opens it for contacts I have emailed who opened nothing in
  90 days; a reply tags `reactivated` and moves them back to Form Filled in the main
  pipeline; 10 unopened sends marks them Suppressed and switches their email consent off.
Put the time-based rules in one `python3 crm.py daily` command. Add
`python3 crm.py board --pipeline <name>` and a weekly review command that lists cards with
no next_action_date or no movement in 14 days. Prove each pipeline with a test contact,
using a fixed "now" you can set from the environment to test the 7, 30 and 90 day rules.
```
