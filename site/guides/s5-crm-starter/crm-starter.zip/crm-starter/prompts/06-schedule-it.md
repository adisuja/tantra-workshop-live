# Prompt 06 · Keep It Running

**Status: PLANNED.**

```
Make intake.py, payments.py and runner.py run every 5 minutes on this Mac without me
opening anything: write a launchd agent (or a cron line on Linux), install it, and show me
how to check its log and how to stop it. They are plain Python: no AI runs on each tick.
One script failing must not stop the other two.
Then add a daily 08:00 summary: new leads, stage moves, messages sent and failed, and
anything stuck, printed to a log I can read. If crm.py has a `daily` command (Prompt 04),
the summary runs it first.
```
