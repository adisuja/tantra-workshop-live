# Prompt 02 · Wire Payments (Checkout → Payment Completed)

**Status: PLANNED.**

```
Read README.md, pipeline.json and crm.py. Only crm.py may write to crm.db: stages move through
its record_event() only, and where a function is missing (there is no way to store
deal_value yet) add a small helper to crm.py.

Build payments.py for my payment provider: <Dodo Payments / Stripe / other>.
1. Find the official API docs for listing successful payments and for verifying a payment
   server-side. Ask me to put the TEST-mode API key in .env (never print or commit it).
   Default to the provider's test host, and refuse the live host until I set an explicit
   switch in .env.
2. Poll for new successful payments every 5 minutes (my machine can't receive webhooks).
   Never trust a browser redirect to say a payment succeeded: only the provider's API.
   Remember the payment ids already recorded, so a payment is never counted twice.
3. For each new payment: make sure the contact exists (add() it with source "<provider>"
   if the buyer never filled in a form), then record_event(email, "payment.succeeded",
   source="<provider>", payload={amount, currency, payment_id}). crm.py adds the
   `purchased` tag. Check the unit: most providers report amounts in cents.
   For a challenge's entry ticket use "payment.entry_succeeded" instead (ask me which
   product id is the entry ticket).
4. Store deal_value on the deal for payment.succeeded.

Prove it with one real test-mode payment, then show `python3 crm.py show <email>`. Run it
twice to prove the second run records nothing. Update README.md's status table for this prompt.
```
