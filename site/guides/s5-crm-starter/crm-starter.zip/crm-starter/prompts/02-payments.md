# Prompt 02 · Wire Payments (Checkout → Payment Completed)

**Status: PLANNED.**

```
Read README.md, pipeline.json and crm.py. Use crm.py's record_event() only.

Build payments.py for my payment provider: <Dodo Payments / Stripe / other>.
1. Find the official API docs for listing successful payments and for verifying a payment
   server-side. Ask me to put the API key in .env (never print or commit it).
2. Poll for new successful payments every 5 minutes (my machine can't receive webhooks).
   Never trust a browser redirect to say a payment succeeded — only the provider's API.
3. For each new payment: record_event(email, "payment.succeeded", source="<provider>",
   payload={amount, currency, payment_id}). crm.py adds the `purchased` tag.
   For a challenge's entry ticket use "payment.entry_succeeded" instead (ask me which
   product id is the entry ticket).
4. Store deal_value on the deal.

Prove it with one real test-mode payment, then show `python3 crm.py show <email>`.
Update README.md's status table for this prompt.
```
