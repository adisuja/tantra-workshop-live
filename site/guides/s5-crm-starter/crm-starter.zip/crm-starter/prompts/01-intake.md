# Prompt 01 · Wire the Intake (Forms and Bookings → CRM)

**Status: PLANNED.** You build this with Claude Code; nothing in this folder does it yet.

Paste into Claude Code, opened in the `crm-starter` folder:

```
Read README.md, pipeline.json, fields.json, schema.sql and crm.py in this folder. crm.py already
stores contacts and events and moves deals: always call its add() and record_event() — never
write to crm.db any other way.

Build intake.py, which brings new leads and bookings into the CRM from these tools:
- My registration / qualification form: <name the tool, e.g. my own Next.js form, Typeform, Tally>
- My booking tool: <Cal.com / Calendly / Google Calendar appointment schedule>

For each tool:
1. Find its official API docs and tell me which endpoint lists new submissions / bookings and
   which API key it needs. Ask me to put the key in a .env file (never print it, never commit it).
2. Poll it (every 5 minutes is enough — this runs on my own machine, so incoming webhooks
   can't reach it) and remember the last item seen in a small state file, so nothing is
   imported twice.
3. Map each item to add(email, name, source, mechanism) using the UTM fields on the form
   (source, utm_source, utm_medium, utm_campaign, utm_content — keep them exactly as named
   in fields.json), then record_event(email, "form.submitted" | "booking.created" |
   "booking.no_show" | "booking.showed", source="<tool>").
4. Deduplicate on email (lower-cased). If a phone number matches a different email, record
   an event "possible.duplicate" instead of merging.

Then: run it once against real data, show me `python3 crm.py board`, and write a
make-believe booking through the tool's test mode to prove the move to Eval Call Scheduled.
Finally, update the status table in README.md for this prompt to BUILT.
```
