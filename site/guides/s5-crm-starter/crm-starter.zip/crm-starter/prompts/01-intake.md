# Prompt 01 · Wire the Intake (Forms and Bookings → CRM)

**Status: PLANNED.** You build this with Claude Code; nothing in this folder does it yet.

Paste into Claude Code, opened in the `crm-starter` folder:

```
Read README.md, pipeline.json, fields.json, schema.sql and crm.py in this folder. crm.py already
stores contacts and events and moves deals. Only crm.py may write to crm.db: every other file
calls its functions. Where a function is missing (add() does not take a phone number or the
UTM fields yet), add a small helper to crm.py and keep its existing commands working.

Build intake.py, which brings new leads and bookings into the CRM from these tools:
- My registration / qualification form: <name the tool, e.g. my own Next.js form, Typeform, Tally>
- My booking tool: <Cal.com / Google Calendar appointment schedule>

For each tool:
1. Find its official API docs and tell me which endpoint lists new submissions / bookings and
   which API key it needs. Ask me to put the key in a .env file (never print it, never commit it).
2. Poll it (every 5 minutes is enough: this runs on my own machine, so incoming webhooks
   can't reach it) and remember what was already imported in a small state file, so nothing is
   imported twice. Run it twice in a row to prove the second run imports nothing.
3. Map each item to add(email, name, source, mechanism) plus the phone number and the UTM
   fields on the form (source, utm_source, utm_medium, utm_campaign, utm_content: keep them
   exactly as named in fields.json, first touch wins), then record_event(email,
   "form.submitted" | "booking.created" | "booking.no_show" | "booking.showed",
   source="<tool>"). Put the booking's start time in the event payload as "start": the
   reminder runner counts back from it.
4. Deduplicate on email (lower-cased). If a phone number matches a different email, record
   an event "possible.duplicate" instead of merging.

Use the standard library only. If an HTTPS call fails with CERTIFICATE_VERIFY_FAILED (Python
from python.org on a Mac), point the request at the system certificates in /etc/ssl/cert.pem.

Then: run it once against real data and show me `python3 crm.py board`. Prove the move to
Eval Call Scheduled with a test booking: book yourself on your own calendar with a second
email address, or, if the booking tool has no account yet, feed intake.py one recorded
booking payload from the tool's docs. Finally, update the status table in README.md for this
prompt to BUILT.
```
